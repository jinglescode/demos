const Octokit = require('@octokit/rest');
const octokit = new Octokit();

export class GithubApi {

    constructor() {

    }

    login(){
        console.log("login");

        var gitToken = "1bdd3f1f0d1c5df24c2e4c607a42708c714e86cf";

        var octokit = new Octokit({
         auth: gitToken
        })


        octokit.repos.getContents({
            owner: "jinglescode",
            repo: "workspace",
            path: "README.md"
        }).then(result => {
            console.log(result);
            let decoded = atob(result.data.content)
            console.log(decoded);

            let encoded = btoa(decoded);
            console.log(encoded);


            let sha = result.data.sha;

            this.update(encoded, sha)
        })

    }

    update(content, sha){
        octokit.repos.createOrUpdateFile({
            owner: "jinglescode",
            repo: "workspace",
            path: "README.md",
            message: "test api",
            content: content,
            sha: sha,
            branch: "master"
        }).then(result => {
            console.log(result)
        })

    }

}