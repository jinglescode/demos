import { Component, OnInit } from '@angular/core';
import { GithubApi } from "./github-api";

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  github_api: GithubApi;

  constructor() { }

  ngOnInit() {
    this.github_api = new GithubApi();

    // this.github_api.login();
  }



}
